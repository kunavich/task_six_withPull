package by.kunavich.task6.data.dao;

import by.kunavich.task6.data.comparator.AuthorBookComparator;
import by.kunavich.task6.model.Book;
import org.junit.Assert;
import org.junit.Test;

public class BookDaoTest {

/*
    @Test
    public void findByTagTest()
    {
        //given
        Book one = new Book("NINE PRINCES IN AMBER","ZELAZNY","ROSMAN",132);
        Book two = new Book("Lir King","Shekspir","HERPER COLINES",43);
        BookDAO = new BookDAO()
        int actual = 1;
        //whenn
        Book answer =authorBookComparator.compare(one,two);
        //then
        Assert.assertTrue(answer >= actual);
   }
 */


}
