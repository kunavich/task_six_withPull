package by.kunavich.task6.data;

public enum  BookField {
    TITEL,
    AUTHOR,
    PUBLISHER,
    LENGTH
}
